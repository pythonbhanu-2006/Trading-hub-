import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd

def create_candlestick_chart(data, title="Price Chart", indicators=None, height=600):
    """
    Create an interactive candlestick chart with indicators
    
    Args:
        data (pandas.DataFrame): OHLCV data with indicators
        title (str): Chart title
        indicators (list): List of indicators to overlay or show as subplots
        height (int): Chart height
        
    Returns:
        plotly.graph_objects.Figure: Plotly figure object
    """
    if data.empty:
        return go.Figure()
    
    # Define indicator types
    overlay_indicators = ['SMA_20', 'SMA_50', 'SMA_200', 'EMA_9', 'EMA_21', 
                         'BB_Upper', 'BB_Middle', 'BB_Lower', 'PSAR', 
                         'ICH_TENKAN', 'ICH_KIJUN']
    
    subplot_indicators = ['RSI', 'MACD', 'MACD_Signal', 'MACD_Hist', 'STOCH_K', 
                         'STOCH_D', 'ADX', 'CCI', 'WILLR', 'OBV']
    
    # Determine which indicators are available in the data
    available_overlays = [ind for ind in overlay_indicators if ind in data.columns]
    available_subplots = []
    
    # Group subplot indicators
    if 'RSI' in data.columns:
        available_subplots.append('RSI')
    
    if 'MACD' in data.columns and 'MACD_Signal' in data.columns:
        available_subplots.append('MACD')
    
    if 'STOCH_K' in data.columns and 'STOCH_D' in data.columns:
        available_subplots.append('STOCH')
    
    if 'ADX' in data.columns:
        available_subplots.append('ADX')
    
    if 'OBV' in data.columns:
        available_subplots.append('OBV')
    
    # Filter indicators if specified
    if indicators is not None:
        available_overlays = [ind for ind in available_overlays if ind in indicators]
        available_subplots = [ind for ind in available_subplots if ind in indicators]
    
    # Create figure with subplots
    fig = make_subplots(
        rows=1 + len(available_subplots),
        cols=1,
        shared_xaxes=True,
        vertical_spacing=0.03,
        row_heights=[0.6] + [0.4 / len(available_subplots)] * len(available_subplots) if available_subplots else [1]
    )
    
    # Add candlestick trace
    fig.add_trace(
        go.Candlestick(
            x=data.index,
            open=data['Open'],
            high=data['High'],
            low=data['Low'],
            close=data['Close'],
            name="Price",
            showlegend=True
        ),
        row=1, col=1
    )
    
    # Add volume as bar chart with reduced opacity
    if 'Volume' in data.columns and not data['Volume'].isna().all():
        colors = ['rgba(0, 255, 0, 0.3)' if row['Close'] >= row['Open'] else 'rgba(255, 0, 0, 0.3)' 
                  for _, row in data.iterrows()]
        
        fig.add_trace(
            go.Bar(
                x=data.index,
                y=data['Volume'],
                name="Volume",
                marker=dict(
                    color=colors
                ),
                opacity=0.3,
                showlegend=True
            ),
            row=1, col=1
        )
    
    # Add overlay indicators
    colors = ['rgba(13, 71, 161, 0.7)', 'rgba(65, 105, 225, 0.7)', 'rgba(33, 150, 243, 0.7)', 
             'rgba(0, 188, 212, 0.7)', 'rgba(0, 150, 136, 0.7)', 'rgba(76, 175, 80, 0.7)']
    
    for i, indicator in enumerate(available_overlays):
        color = colors[i % len(colors)]
        
        if 'BB_' in indicator:
            if indicator == 'BB_Upper':
                fig.add_trace(
                    go.Scatter(
                        x=data.index,
                        y=data[indicator],
                        name="Bollinger Upper",
                        line=dict(color='rgba(255, 165, 0, 0.7)', width=1),
                        showlegend=True
                    ),
                    row=1, col=1
                )
            elif indicator == 'BB_Lower':
                fig.add_trace(
                    go.Scatter(
                        x=data.index,
                        y=data[indicator],
                        name="Bollinger Lower",
                        line=dict(color='rgba(255, 165, 0, 0.7)', width=1),
                        fill='tonexty',
                        fillcolor='rgba(255, 165, 0, 0.05)',
                        showlegend=True
                    ),
                    row=1, col=1
                )
            elif indicator == 'BB_Middle':
                fig.add_trace(
                    go.Scatter(
                        x=data.index,
                        y=data[indicator],
                        name="Bollinger Middle",
                        line=dict(color='rgba(255, 165, 0, 0.7)', width=1, dash='dash'),
                        showlegend=True
                    ),
                    row=1, col=1
                )
        elif indicator == 'PSAR':
            fig.add_trace(
                go.Scatter(
                    x=data.index,
                    y=data[indicator],
                    name="Parabolic SAR",
                    mode='markers',
                    marker=dict(
                        symbol='circle',
                        size=3,
                        color='rgba(255, 255, 255, 0.7)'
                    ),
                    showlegend=True
                ),
                row=1, col=1
            )
        else:
            fig.add_trace(
                go.Scatter(
                    x=data.index,
                    y=data[indicator],
                    name=indicator,
                    line=dict(color=color),
                    showlegend=True
                ),
                row=1, col=1
            )
    
    # Add subplot indicators
    current_row = 2
    
    if 'RSI' in available_subplots:
        fig.add_trace(
            go.Scatter(
                x=data.index,
                y=data['RSI'],
                name="RSI",
                line=dict(color='rgba(156, 39, 176, 0.7)'),
                showlegend=True
            ),
            row=current_row, col=1
        )
        
        # Add RSI overbought/oversold lines
        fig.add_trace(
            go.Scatter(
                x=[data.index[0], data.index[-1]],
                y=[70, 70],
                name="Overbought",
                line=dict(color='rgba(255, 0, 0, 0.5)', width=1, dash='dash'),
                showlegend=False
            ),
            row=current_row, col=1
        )
        
        fig.add_trace(
            go.Scatter(
                x=[data.index[0], data.index[-1]],
                y=[30, 30],
                name="Oversold",
                line=dict(color='rgba(0, 255, 0, 0.5)', width=1, dash='dash'),
                showlegend=False
            ),
            row=current_row, col=1
        )
        
        current_row += 1
    
    if 'MACD' in available_subplots:
        fig.add_trace(
            go.Scatter(
                x=data.index,
                y=data['MACD'],
                name="MACD",
                line=dict(color='rgba(38, 166, 154, 0.7)'),
                showlegend=True
            ),
            row=current_row, col=1
        )
        
        fig.add_trace(
            go.Scatter(
                x=data.index,
                y=data['MACD_Signal'],
                name="MACD Signal",
                line=dict(color='rgba(239, 83, 80, 0.7)'),
                showlegend=True
            ),
            row=current_row, col=1
        )
        
        colors = ['rgba(0, 255, 0, 0.5)' if val >= 0 else 'rgba(255, 0, 0, 0.5)' for val in data['MACD_Hist']]
        
        fig.add_trace(
            go.Bar(
                x=data.index,
                y=data['MACD_Hist'],
                name="MACD Histogram",
                marker=dict(color=colors),
                showlegend=True
            ),
            row=current_row, col=1
        )
        
        current_row += 1
    
    if 'STOCH' in available_subplots:
        fig.add_trace(
            go.Scatter(
                x=data.index,
                y=data['STOCH_K'],
                name="Stochastic %K",
                line=dict(color='rgba(66, 165, 245, 0.7)'),
                showlegend=True
            ),
            row=current_row, col=1
        )
        
        fig.add_trace(
            go.Scatter(
                x=data.index,
                y=data['STOCH_D'],
                name="Stochastic %D",
                line=dict(color='rgba(233, 30, 99, 0.7)'),
                showlegend=True
            ),
            row=current_row, col=1
        )
        
        # Add overbought/oversold lines
        fig.add_trace(
            go.Scatter(
                x=[data.index[0], data.index[-1]],
                y=[80, 80],
                name="Overbought",
                line=dict(color='rgba(255, 0, 0, 0.5)', width=1, dash='dash'),
                showlegend=False
            ),
            row=current_row, col=1
        )
        
        fig.add_trace(
            go.Scatter(
                x=[data.index[0], data.index[-1]],
                y=[20, 20],
                name="Oversold",
                line=dict(color='rgba(0, 255, 0, 0.5)', width=1, dash='dash'),
                showlegend=False
            ),
            row=current_row, col=1
        )
        
        current_row += 1
    
    if 'ADX' in available_subplots:
        fig.add_trace(
            go.Scatter(
                x=data.index,
                y=data['ADX'],
                name="ADX",
                line=dict(color='rgba(255, 193, 7, 0.7)'),
                showlegend=True
            ),
            row=current_row, col=1
        )
        
        # Add strong trend line
        fig.add_trace(
            go.Scatter(
                x=[data.index[0], data.index[-1]],
                y=[25, 25],
                name="Strong Trend",
                line=dict(color='rgba(255, 0, 0, 0.5)', width=1, dash='dash'),
                showlegend=False
            ),
            row=current_row, col=1
        )
        
        current_row += 1
    
    if 'OBV' in available_subplots:
        fig.add_trace(
            go.Scatter(
                x=data.index,
                y=data['OBV'],
                name="OBV",
                line=dict(color='rgba(121, 85, 72, 0.7)'),
                showlegend=True
            ),
            row=current_row, col=1
        )
        
        current_row += 1
    
    # Update layout
    fig.update_layout(
        title=title,
        xaxis_title="Date",
        height=height,
        template="plotly_dark",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        ),
        margin=dict(l=10, r=10, t=60, b=10)
    )
    
    # Hide weekends and after hours if using day-level data
    if 'D' in data.index.freq if data.index.freq else '':
        fig.update_xaxes(
            rangebreaks=[
                dict(bounds=["sat", "mon"]),  # Hide weekends
                dict(bounds=[16, 9.5], pattern="hour")  # Hide after hours (outside 9:30 - 16:00)
            ]
        )
    
    # Update y-axis labels
    fig.update_yaxes(title_text="Price", row=1, col=1)
    
    current_row = 2
    if 'RSI' in available_subplots:
        fig.update_yaxes(title_text="RSI", row=current_row, col=1)
        current_row += 1
    
    if 'MACD' in available_subplots:
        fig.update_yaxes(title_text="MACD", row=current_row, col=1)
        current_row += 1
    
    if 'STOCH' in available_subplots:
        fig.update_yaxes(title_text="Stochastic", row=current_row, col=1)
        current_row += 1
    
    if 'ADX' in available_subplots:
        fig.update_yaxes(title_text="ADX", row=current_row, col=1)
        current_row += 1
    
    if 'OBV' in available_subplots:
        fig.update_yaxes(title_text="OBV", row=current_row, col=1)
        current_row += 1
    
    return fig
