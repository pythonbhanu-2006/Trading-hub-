import yfinance as yf
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
from assets.symbol_mappings import SYMBOL_MAPPING, TIMEFRAME_LIMITS

def get_mapped_symbol(symbol):
    """Map user-friendly symbol to yfinance symbol if needed"""
    return SYMBOL_MAPPING.get(symbol, symbol)

def calculate_start_date(timeframe):
    """Calculate start date based on timeframe limits"""
    if TIMEFRAME_LIMITS[timeframe] is None:
        return None
    
    return datetime.now() - timedelta(days=TIMEFRAME_LIMITS[timeframe])

def fetch_data(symbol, timeframe="1d", period=None, limit=None):
    """
    Fetch market data from Yahoo Finance
    
    Args:
        symbol (str): The ticker symbol
        timeframe (str): Candlestick timeframe (1m, 5m, 15m, 1h, 4h, 1d, 1w, 1mo)
        period (str, optional): Time period (1d, 5d, 1mo, 3mo, 6mo, 1y, 2y, 5y, 10y, ytd, max)
        limit (int, optional): Limit number of records
        
    Returns:
        tuple: (dataframe of historical data, live price)
    """
    try:
        # Get the mapped symbol
        yf_symbol = get_mapped_symbol(symbol)
        
        # Create ticker object
        ticker = yf.Ticker(yf_symbol)
        
        # Get start date based on timeframe limits
        start_date = calculate_start_date(timeframe) if period is None else None
        
        # Fetch historical data
        if period is not None:
            historical_data = ticker.history(period=period, interval=timeframe)
        elif start_date is not None:
            historical_data = ticker.history(start=start_date, interval=timeframe)
        else:
            historical_data = ticker.history(period="max", interval=timeframe)
        
        if historical_data.empty:
            # Try fallback timeframes
            fallback_timeframes = ["1h", "1d", "1wk"]
            for fallback in fallback_timeframes:
                if fallback != timeframe:
                    if period is not None:
                        historical_data = ticker.history(period=period, interval=fallback)
                    elif start_date is not None:
                        historical_data = ticker.history(start=start_date, interval=fallback)
                    else:
                        historical_data = ticker.history(period="max", interval=fallback)
                    
                    if not historical_data.empty:
                        break
        
        # Apply limit if specified
        if limit is not None and not historical_data.empty:
            historical_data = historical_data.iloc[-limit:]
        
        # Get live price
        live_price = ticker.info.get('regularMarketPrice', 
                                    historical_data['Close'].iloc[-1] if not historical_data.empty else None)
        
        return historical_data, live_price, ticker.info
    
    except Exception as e:
        print(f"Error fetching data for {symbol}: {e}")
        return pd.DataFrame(), None, {}

def get_ticker_info(symbol):
    """Get basic information about a ticker"""
    try:
        yf_symbol = get_mapped_symbol(symbol)
        ticker = yf.Ticker(yf_symbol)
        return ticker.info
    except Exception as e:
        print(f"Error getting info for {symbol}: {e}")
        return {}

def search_symbols(query):
    """Search for symbols matching the query (placeholder for actual search)"""
    # For simplicity, just filter predefined markets
    from assets.symbol_mappings import PREDEFINED_MARKETS
    if not query:
        return PREDEFINED_MARKETS
    
    return [m for m in PREDEFINED_MARKETS if query.lower() in m.lower()]
