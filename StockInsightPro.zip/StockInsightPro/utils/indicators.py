"""
Technical indicators module for financial market analysis.
This module calculates various technical indicators used for market analysis and trading signals.
"""

import pandas as pd
import numpy as np

def calculate_indicators(df):
    """
    Calculate a comprehensive set of technical indicators for market analysis.
    
    Args:
        df (pandas.DataFrame): DataFrame with OHLCV data (Open, High, Low, Close, Volume)
        
    Returns:
        pandas.DataFrame: DataFrame with indicators added
    """
    # Make a copy of the dataframe to avoid modifying the original
    df = df.copy()
    
    # Basic checks
    if df.empty:
        return df
    
    if not all(col in df.columns for col in ['Open', 'High', 'Low', 'Close', 'Volume']):
        raise ValueError("DataFrame must contain OHLCV data (Open, High, Low, Close, Volume)")
    
    # Ensure numeric data
    for col in ['Open', 'High', 'Low', 'Close', 'Volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    
    # Drop rows with NaN values in critical columns
    df = df.dropna(subset=['Close', 'High', 'Low'])
    
    # 1. Moving Averages
    df['SMA_5'] = df['Close'].rolling(window=5).mean()
    df['SMA_10'] = df['Close'].rolling(window=10).mean()
    df['SMA_20'] = df['Close'].rolling(window=20).mean()
    df['SMA_50'] = df['Close'].rolling(window=50).mean()
    df['SMA_100'] = df['Close'].rolling(window=100).mean()
    df['SMA_200'] = df['Close'].rolling(window=200).mean()
    
    # 2. Exponential Moving Averages
    df['EMA_5'] = df['Close'].ewm(span=5, adjust=False).mean()
    df['EMA_10'] = df['Close'].ewm(span=10, adjust=False).mean()
    df['EMA_20'] = df['Close'].ewm(span=20, adjust=False).mean()
    df['EMA_50'] = df['Close'].ewm(span=50, adjust=False).mean()
    df['EMA_100'] = df['Close'].ewm(span=100, adjust=False).mean()
    df['EMA_200'] = df['Close'].ewm(span=200, adjust=False).mean()
    
    # 3. MACD (Moving Average Convergence Divergence)
    df['MACD_Line'] = df['Close'].ewm(span=12, adjust=False).mean() - df['Close'].ewm(span=26, adjust=False).mean()
    df['MACD_Signal'] = df['MACD_Line'].ewm(span=9, adjust=False).mean()
    df['MACD_Histogram'] = df['MACD_Line'] - df['MACD_Signal']
    
    # 4. RSI (Relative Strength Index)
    delta = df['Close'].diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    
    avg_gain = gain.rolling(window=14).mean()
    avg_loss = loss.rolling(window=14).mean()
    
    rs = avg_gain / avg_loss
    df['RSI_14'] = 100 - (100 / (1 + rs))
    
    # 5. Stochastic Oscillator
    n = 14  # Standard lookback period
    df['STOCH_K'] = ((df['Close'] - df['Low'].rolling(window=n).min()) / 
                     (df['High'].rolling(window=n).max() - df['Low'].rolling(window=n).min())) * 100
    df['STOCH_D'] = df['STOCH_K'].rolling(window=3).mean()
    
    # 6. Average True Range (ATR)
    high_low = df['High'] - df['Low']
    high_close = (df['High'] - df['Close'].shift()).abs()
    low_close = (df['Low'] - df['Close'].shift()).abs()
    
    tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    df['ATR_14'] = tr.rolling(window=14).mean()
    
    # 7. Bollinger Bands
    df['BB_Middle'] = df['Close'].rolling(window=20).mean()
    std_dev = df['Close'].rolling(window=20).std()
    df['BB_Upper'] = df['BB_Middle'] + (2 * std_dev)
    df['BB_Lower'] = df['BB_Middle'] - (2 * std_dev)
    df['BB_Width'] = (df['BB_Upper'] - df['BB_Lower']) / df['BB_Middle']
    
    # 8. Average Directional Index (ADX)
    # Simplified calculation for ADX
    up_move = df['High'].diff()
    down_move = df['Low'].diff().multiply(-1)
    
    pos_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0)
    neg_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0)
    
    tr_arr = tr.values  # Use true range from ATR calculation
    
    pos_di = pd.Series(pos_dm).rolling(window=14).mean() / tr.rolling(window=14).mean() * 100
    neg_di = pd.Series(neg_dm).rolling(window=14).mean() / tr.rolling(window=14).mean() * 100
    
    dx = (abs(pos_di - neg_di) / (pos_di + neg_di)) * 100
    df['ADX'] = dx.rolling(window=14).mean()
    df['DI_Pos'] = pos_di
    df['DI_Neg'] = neg_di
    
    # 9. On-Balance Volume (OBV)
    df['OBV'] = (np.sign(df['Close'].diff()) * df['Volume']).fillna(0).cumsum()
    
    # 10. Volume-Weighted Average Price (VWAP)
    df['VWAP'] = (df['Volume'] * (df['High'] + df['Low'] + df['Close']) / 3).cumsum() / df['Volume'].cumsum()
    
    # 11. Williams %R
    n = 14  # Standard lookback period
    df['WILLR'] = ((df['High'].rolling(window=n).max() - df['Close']) / 
                  (df['High'].rolling(window=n).max() - df['Low'].rolling(window=n).min())) * -100
    
    # 12. Commodity Channel Index (CCI)
    typical_price = (df['High'] + df['Low'] + df['Close']) / 3
    mean_dev = pd.Series([abs(typical_price[i] - typical_price[i-20:i].mean()) for i in range(20, len(typical_price))])
    df['CCI'] = (typical_price - typical_price.rolling(window=20).mean()) / (0.015 * mean_dev)
    
    # 13. Parabolic SAR (Simplified)
    # This is a simplified calculation; true PSAR is more complex
    df['PSAR'] = df['Close'].shift(1) - 0.02 * (df['Close'].shift(1) - df['Low'].shift(1))
    
    # 14. Ichimoku Cloud Components
    high_9 = df['High'].rolling(window=9).max()
    low_9 = df['Low'].rolling(window=9).min()
    df['ICH_TENKAN'] = (high_9 + low_9) / 2  # Conversion Line
    
    high_26 = df['High'].rolling(window=26).max()
    low_26 = df['Low'].rolling(window=26).min()
    df['ICH_KIJUN'] = (high_26 + low_26) / 2  # Base Line
    
    df['ICH_SENKOU_A'] = ((df['ICH_TENKAN'] + df['ICH_KIJUN']) / 2).shift(26)  # Leading Span A
    
    high_52 = df['High'].rolling(window=52).max()
    low_52 = df['Low'].rolling(window=52).min()
    df['ICH_SENKOU_B'] = ((high_52 + low_52) / 2).shift(26)  # Leading Span B
    
    df['ICH_CHIKOU'] = df['Close'].shift(-26)  # Lagging Span
    
    # 15. Keltner Channel
    df['KC_Middle'] = df['EMA_20']
    df['KC_Upper'] = df['KC_Middle'] + (2 * df['ATR_14'])
    df['KC_Lower'] = df['KC_Middle'] - (2 * df['ATR_14'])
    
    # 16. Rate of Change (ROC)
    df['ROC_10'] = ((df['Close'] / df['Close'].shift(10)) - 1) * 100
    
    # 17. Money Flow Index (MFI)
    typical_price = (df['High'] + df['Low'] + df['Close']) / 3
    raw_money_flow = typical_price * df['Volume']
    
    positive_flow = raw_money_flow.where(typical_price > typical_price.shift(1), 0).rolling(window=14).sum()
    negative_flow = raw_money_flow.where(typical_price < typical_price.shift(1), 0).rolling(window=14).sum()
    
    money_ratio = positive_flow / negative_flow
    df['MFI'] = 100 - (100 / (1 + money_ratio))
    
    # 18. Chaikin Money Flow (CMF)
    mf_multiplier = ((df['Close'] - df['Low']) - (df['High'] - df['Close'])) / (df['High'] - df['Low'])
    mf_volume = mf_multiplier * df['Volume']
    df['CMF'] = mf_volume.rolling(window=20).sum() / df['Volume'].rolling(window=20).sum()
    
    # 19. Fibonacci Retracement Levels (based on recent high/low)
    # Note: These are static and not true Fibonacci retracements but simplified indicators
    if len(df) > 50:  # Only calculate if we have enough data
        recent_high = df['High'][-50:].max()
        recent_low = df['Low'][-50:].min()
        range_price = recent_high - recent_low
        
        df['FIBO_236'] = recent_high - 0.236 * range_price
        df['FIBO_382'] = recent_high - 0.382 * range_price
        df['FIBO_500'] = recent_high - 0.500 * range_price
        df['FIBO_618'] = recent_high - 0.618 * range_price
    
    # 20. Force Index
    df['FORCE_13'] = df['Close'].diff(1) * df['Volume'].rolling(window=13).mean()
    
    # 21. Ease of Movement (EOM)
    move = ((df['High'] + df['Low']) / 2) - ((df['High'].shift(1) + df['Low'].shift(1)) / 2)
    box_ratio = (df['Volume'] / 1000000) / (df['High'] - df['Low'])
    df['EOM_14'] = (move / box_ratio).rolling(window=14).mean()
    
    # 22. Coppock Curve
    roc1 = ((df['Close'] / df['Close'].shift(14)) - 1) * 100
    roc2 = ((df['Close'] / df['Close'].shift(11)) - 1) * 100
    df['COPP'] = (roc1 + roc2).ewm(span=10, min_periods=10).mean()
    
    # 23. Aroon Indicator
    df['AROON_UP'] = df['High'].rolling(window=25).apply(lambda x: float(np.argmax(x) + 1) / len(x) * 100, raw=True)
    df['AROON_DOWN'] = df['Low'].rolling(window=25).apply(lambda x: float(np.argmin(x) + 1) / len(x) * 100, raw=True)
    df['AROON_OSC'] = df['AROON_UP'] - df['AROON_DOWN']
    
    # 24. Relative Vigor Index (RVI)
    close_open = df['Close'] - df['Open']
    high_low = df['High'] - df['Low']
    
    numerator = close_open.rolling(window=10).mean()
    denominator = high_low.rolling(window=10).mean()
    
    df['RVI'] = numerator / denominator
    
    # 25. Detrended Price Oscillator (DPO)
    df['DPO'] = df['Close'] - df['Close'].rolling(window=20).mean().shift(11)
    
    # 26. Mass Index
    range_high_low = df['High'] - df['Low']
    ema1 = range_high_low.ewm(span=9, min_periods=9).mean()
    ema2 = ema1.ewm(span=9, min_periods=9).mean()
    ratio = ema1 / ema2
    df['MASS'] = ratio.rolling(window=25).sum()
    
    # 27. Know Sure Thing (KST)
    roc10 = ((df['Close'] / df['Close'].shift(10)) - 1) * 100
    roc15 = ((df['Close'] / df['Close'].shift(15)) - 1) * 100
    roc20 = ((df['Close'] / df['Close'].shift(20)) - 1) * 100
    roc30 = ((df['Close'] / df['Close'].shift(30)) - 1) * 100
    
    kst = (roc10.rolling(window=10).mean() * 1) + (roc15.rolling(window=10).mean() * 2) + \
          (roc20.rolling(window=10).mean() * 3) + (roc30.rolling(window=15).mean() * 4)
    df['KST'] = kst
    df['KST_SIGNAL'] = df['KST'].rolling(window=9).mean()
    
    # 28. Percentage Price Oscillator (PPO)
    df['PPO'] = ((df['EMA_12'] - df['EMA_26']) / df['EMA_26']) * 100
    df['PPO_SIGNAL'] = df['PPO'].ewm(span=9, min_periods=9).mean()
    df['PPO_HIST'] = df['PPO'] - df['PPO_SIGNAL']
    
    # 29. Awesome Oscillator (AO)
    median_price = (df['High'] + df['Low']) / 2
    ao = median_price.rolling(window=5).mean() - median_price.rolling(window=34).mean()
    df['AO'] = ao
    
    # 30. Ultimate Oscillator (UO)
    bp = df['Close'] - df['Low'].combine(df['Close'].shift(1), min)
    tr = df['High'].combine(df['Close'].shift(1), max) - df['Low'].combine(df['Close'].shift(1), min)
    
    avg7 = bp.rolling(window=7).sum() / tr.rolling(window=7).sum()
    avg14 = bp.rolling(window=14).sum() / tr.rolling(window=14).sum()
    avg28 = bp.rolling(window=28).sum() / tr.rolling(window=28).sum()
    
    df['UO'] = 100 * ((4 * avg7) + (2 * avg14) + avg28) / 7
    
    # 31. Hull Moving Average (HMA)
    df['HMA_9'] = (2 * df['Close'].ewm(span=4, adjust=False).mean()) - df['Close'].ewm(span=9, adjust=False).mean()
    
    # 32. SuperTrend (simplified version)
    atr = df['ATR_14']
    upper_band = ((df['High'] + df['Low']) / 2) + (2 * atr)
    lower_band = ((df['High'] + df['Low']) / 2) - (2 * atr)
    
    # Initialize SuperTrend
    df['ST_DIRECTION'] = 0
    df['SUPERTREND'] = 0
    
    # Calculate first value
    if df['Close'].iloc[0] <= upper_band.iloc[0]:
        df['ST_DIRECTION'].iloc[0] = -1
        df['SUPERTREND'].iloc[0] = upper_band.iloc[0]
    else:
        df['ST_DIRECTION'].iloc[0] = 1
        df['SUPERTREND'].iloc[0] = lower_band.iloc[0]
    
    # Calculate SuperTrend
    for i in range(1, len(df)):
        curr_close = df['Close'].iloc[i]
        prev_supertrend = df['SUPERTREND'].iloc[i-1]
        curr_upper = upper_band.iloc[i]
        curr_lower = lower_band.iloc[i]
        prev_direction = df['ST_DIRECTION'].iloc[i-1]
        
        # Determine current direction and value
        if prev_supertrend <= curr_close:
            curr_direction = 1
            curr_supertrend = curr_lower
        else:
            curr_direction = -1
            curr_supertrend = curr_upper
            
        # Update values    
        df['ST_DIRECTION'].iloc[i] = curr_direction
        df['SUPERTREND'].iloc[i] = curr_supertrend
    
    # Replace any potential infinity or NaN values with NaN
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    
    # Calculate consolidated indicator score (normalized from 0-100)
    # This aggregates key indicators for a snapshot of overall market conditions
    indicators = []
    
    # RSI (0-100 already)
    indicators.append(df['RSI_14'])
    
    # Stochastic (0-100 already)
    indicators.append(df['STOCH_K'])
    
    # MACD normalized
    macd_max = max(df['MACD_Line'].max(), abs(df['MACD_Line'].min()))
    if macd_max != 0:
        indicators.append((df['MACD_Line'] / macd_max) * 50 + 50)
    
    # Bollinger Band position (0-100%)
    bb_pos = (df['Close'] - df['BB_Lower']) / (df['BB_Upper'] - df['BB_Lower']) * 100
    indicators.append(bb_pos)
    
    # Williams %R (shifted from -100-0 to 0-100)
    indicators.append(df['WILLR'] + 100)
    
    # CCI normalized
    cci_max = max(df['CCI'].max(), abs(df['CCI'].min()))
    if cci_max != 0:
        indicators.append((df['CCI'] / cci_max) * 50 + 50)
    
    # MFI (0-100 already)
    indicators.append(df['MFI'])
    
    # ADX (0-100 already)
    indicators.append(df['ADX'])
    
    # Combined score (average of normalized indicators)
    valid_indicators = [i for i in indicators if not i.isna().all()]
    if valid_indicators:
        df['COMPOSITE_SCORE'] = pd.concat(valid_indicators, axis=1).mean(axis=1)
    
    return df

def get_indicator_summary(data):
    """
    Create a summary of indicator signals for the most recent data point.
    
    Args:
        data (pandas.DataFrame): DataFrame with calculated indicators
        
    Returns:
        dict: Dictionary of indicator signals
    """
    # Check if we have data
    if data.empty:
        return {"error": "No data available for indicators"}
    
    # Get the most recent row with complete indicator data
    recent_data = data.iloc[-1]
    
    signals = {}
    
    # Moving Averages
    signals["SMA_20"] = "Above Price" if recent_data.get('SMA_20', 0) > recent_data['Close'] else "Below Price"
    signals["SMA_50"] = "Above Price" if recent_data.get('SMA_50', 0) > recent_data['Close'] else "Below Price"
    signals["SMA_200"] = "Above Price" if recent_data.get('SMA_200', 0) > recent_data['Close'] else "Below Price"
    
    # EMA Crossovers
    signals["EMA_Cross"] = "Bullish" if recent_data.get('EMA_5', 0) > recent_data.get('EMA_20', 0) else "Bearish"
    
    # MACD
    macd = recent_data.get('MACD_Line', 0)
    macd_signal = recent_data.get('MACD_Signal', 0)
    signals["MACD"] = "Bullish" if macd > macd_signal else "Bearish"
    signals["MACD_Value"] = round(macd, 2) if pd.notna(macd) else "N/A"
    
    # RSI
    rsi = recent_data.get('RSI_14', 0)
    if pd.notna(rsi):
        if rsi > 70:
            signals["RSI"] = "Overbought"
        elif rsi < 30:
            signals["RSI"] = "Oversold"
        else:
            signals["RSI"] = "Neutral"
        signals["RSI_Value"] = round(rsi, 2)
    else:
        signals["RSI"] = "N/A"
        signals["RSI_Value"] = "N/A"
    
    # Stochastic
    stoch_k = recent_data.get('STOCH_K', 0)
    stoch_d = recent_data.get('STOCH_D', 0)
    if pd.notna(stoch_k) and pd.notna(stoch_d):
        if stoch_k > 80 and stoch_d > 80:
            signals["Stochastic"] = "Overbought"
        elif stoch_k < 20 and stoch_d < 20:
            signals["Stochastic"] = "Oversold"
        else:
            signals["Stochastic"] = "Neutral"
        signals["Stochastic_K"] = round(stoch_k, 2)
        signals["Stochastic_D"] = round(stoch_d, 2)
    else:
        signals["Stochastic"] = "N/A"
        signals["Stochastic_K"] = "N/A"
        signals["Stochastic_D"] = "N/A"
    
    # ADX (Trend Strength)
    adx = recent_data.get('ADX', 0)
    if pd.notna(adx):
        if adx > 25:
            signals["ADX"] = "Strong Trend"
        else:
            signals["ADX"] = "Weak Trend"
        signals["ADX_Value"] = round(adx, 2)
    else:
        signals["ADX"] = "N/A"
        signals["ADX_Value"] = "N/A"
    
    # Bollinger Bands
    bb_upper = recent_data.get('BB_Upper', 0)
    bb_lower = recent_data.get('BB_Lower', 0)
    close = recent_data['Close']
    
    if pd.notna(bb_upper) and pd.notna(bb_lower):
        if close > bb_upper:
            signals["Bollinger"] = "Above Upper Band"
        elif close < bb_lower:
            signals["Bollinger"] = "Below Lower Band"
        else:
            signals["Bollinger"] = "Inside Bands"
        
        # Calculate percentage position within bands (0-100%)
        band_width = bb_upper - bb_lower
        if band_width > 0:
            position = ((close - bb_lower) / band_width) * 100
            signals["BB_Position"] = round(position, 2)
        else:
            signals["BB_Position"] = "N/A"
    else:
        signals["Bollinger"] = "N/A"
        signals["BB_Position"] = "N/A"
    
    # ATR (Volatility)
    atr = recent_data.get('ATR_14', 0)
    if pd.notna(atr):
        atr_percent = (atr / close) * 100
        signals["ATR"] = round(atr, 4)
        signals["ATR_Percent"] = round(atr_percent, 2)
    else:
        signals["ATR"] = "N/A"
        signals["ATR_Percent"] = "N/A"
    
    # Ichimoku Cloud Status
    tenkan = recent_data.get('ICH_TENKAN', 0)
    kijun = recent_data.get('ICH_KIJUN', 0)
    senkou_a = recent_data.get('ICH_SENKOU_A', 0)
    senkou_b = recent_data.get('ICH_SENKOU_B', 0)
    
    if all(pd.notna(x) for x in [tenkan, kijun, senkou_a, senkou_b]):
        if close > max(senkou_a, senkou_b):
            signals["Ichimoku"] = "Above Cloud (Bullish)"
        elif close < min(senkou_a, senkou_b):
            signals["Ichimoku"] = "Below Cloud (Bearish)"
        else:
            signals["Ichimoku"] = "In Cloud (Neutral)"
        
        signals["Tenkan/Kijun"] = "Bullish" if tenkan > kijun else "Bearish"
    else:
        signals["Ichimoku"] = "N/A"
        signals["Tenkan/Kijun"] = "N/A"
    
    # OBV (On-Balance Volume)
    obv = recent_data.get('OBV', 0)
    if pd.notna(obv) and len(data) > 1:
        prev_obv = data.iloc[-2].get('OBV', 0)
        if pd.notna(prev_obv):
            signals["OBV"] = "Rising" if obv > prev_obv else "Falling"
        else:
            signals["OBV"] = "N/A"
    else:
        signals["OBV"] = "N/A"
    
    # Composite Technical Score
    composite = recent_data.get('COMPOSITE_SCORE', 0)
    if pd.notna(composite):
        signals["Composite_Score"] = round(composite, 2)
        if composite > 70:
            signals["Market_Condition"] = "Strongly Bullish"
        elif composite > 60:
            signals["Market_Condition"] = "Bullish"
        elif composite > 40:
            signals["Market_Condition"] = "Neutral"
        elif composite > 30:
            signals["Market_Condition"] = "Bearish"
        else:
            signals["Market_Condition"] = "Strongly Bearish"
    else:
        signals["Composite_Score"] = "N/A"
        signals["Market_Condition"] = "N/A"
    
    # SuperTrend
    supertrend = recent_data.get('SUPERTREND', 0)
    direction = recent_data.get('ST_DIRECTION', 0)
    if pd.notna(supertrend) and pd.notna(direction):
        signals["SuperTrend"] = "Bullish" if direction > 0 else "Bearish"
        signals["SuperTrend_Price"] = round(supertrend, 2)
    else:
        signals["SuperTrend"] = "N/A"
        signals["SuperTrend_Price"] = "N/A"
    
    # Additional Oscillators
    # MFI
    mfi = recent_data.get('MFI', 0)
    if pd.notna(mfi):
        if mfi > 80:
            signals["MFI"] = "Overbought"
        elif mfi < 20:
            signals["MFI"] = "Oversold"
        else:
            signals["MFI"] = "Neutral"
        signals["MFI_Value"] = round(mfi, 2)
    else:
        signals["MFI"] = "N/A"
        signals["MFI_Value"] = "N/A"
    
    # CCI
    cci = recent_data.get('CCI', 0)
    if pd.notna(cci):
        if cci > 100:
            signals["CCI"] = "Overbought"
        elif cci < -100:
            signals["CCI"] = "Oversold"
        else:
            signals["CCI"] = "Neutral"
        signals["CCI_Value"] = round(cci, 2)
    else:
        signals["CCI"] = "N/A"
        signals["CCI_Value"] = "N/A"
    
    # Williams %R
    willr = recent_data.get('WILLR', 0)
    if pd.notna(willr):
        if willr > -20:
            signals["Williams %R"] = "Overbought"
        elif willr < -80:
            signals["Williams %R"] = "Oversold"
        else:
            signals["Williams %R"] = "Neutral"
        signals["Williams %R_Value"] = round(willr, 2)
    else:
        signals["Williams %R"] = "N/A"
        signals["Williams %R_Value"] = "N/A"
    
    # Awesome Oscillator
    ao = recent_data.get('AO', 0)
    if pd.notna(ao):
        signals["AO"] = "Positive" if ao > 0 else "Negative"
        signals["AO_Value"] = round(ao, 2)
    else:
        signals["AO"] = "N/A"
        signals["AO_Value"] = "N/A"
    
    # Convert any numpy data types to Python native types for JSON compatibility
    for key, value in signals.items():
        if isinstance(value, (np.integer, np.floating)):
            signals[key] = float(value)
    
    return signals

def format_indicator_data(data):
    """Format indicator data for API consumption"""
    if data is None or data.empty:
        return {}
        
    # Get the most recent complete row of data
    recent = data.iloc[-1].to_dict()
    
    # Clean up the data (remove NaN, convert to Python native types)
    cleaned = {}
    for key, value in recent.items():
        if pd.notna(value):
            if isinstance(value, (np.integer, np.floating)):
                cleaned[key] = float(value)
            else:
                cleaned[key] = value
    
    return cleaned

def format_historical_data(data, limit=10):
    """Format recent historical data for API consumption"""
    if data is None or data.empty:
        return []
        
    # Get the most recent rows
    recent_data = data.tail(limit).copy()
    
    # Format to dictionary
    result = []
    for idx, row in recent_data.iterrows():
        item = {
            "date": idx.strftime('%Y-%m-%d %H:%M:%S'),
            "open": float(row['Open']),
            "high": float(row['High']),
            "low": float(row['Low']),
            "close": float(row['Close']),
            "volume": float(row['Volume'])
        }
        result.append(item)
    
    return result