import os
from openai import OpenAI
import json
import pandas as pd

# OpenAI setup with Azure endpoint
api_key = os.environ.get("OPENAI_API_KEY", "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")
base_url = "https://models.inference.ai.azure.com"
client = OpenAI(api_key=api_key, base_url=base_url)

def format_indicator_data(data):
    """Format indicator data for API consumption"""
    if data.empty:
        return "No data available"
    
    last_row = data.iloc[-1]
    formatted = {}
    
    for col in data.columns:
        if col in ['Open', 'High', 'Low', 'Close', 'Volume']:
            continue
        if pd.notna(last_row[col]):
            formatted[col] = float(last_row[col])
    
    return json.dumps(formatted, indent=2)

def format_historical_data(data, limit=10):
    """Format recent historical data for API consumption"""
    if data.empty:
        return "No data available"
    
    recent = data.iloc[-limit:].copy()
    
    # Format the data as string
    formatted = []
    for _, row in recent.iterrows():
        candle = {
            "date": row.name.strftime("%Y-%m-%d %H:%M"),
            "open": float(row['Open']),
            "high": float(row['High']),
            "low": float(row['Low']),
            "close": float(row['Close']),
            "volume": float(row['Volume']) if 'Volume' in row and pd.notna(row['Volume']) else None
        }
        formatted.append(candle)
    
    return json.dumps(formatted, indent=2)

def get_market_analysis(symbol, data, live_price, style, risk_reward="1:2"):
    """
    Get market analysis from OpenAI
    
    Args:
        symbol (str): The ticker symbol
        data (pandas.DataFrame): Historical price data with indicators
        live_price (float): Current live price
        style (str): Analysis style (Technical, Trend Following, etc.)
        risk_reward (str): Risk-reward ratio
        
    Returns:
        str: Analysis text
    """
    from assets.symbol_mappings import ANALYSIS_STYLES
    
    if client is None:
        return "OpenAI API key not configured. Please set the OPENAI_API_KEY environment variable."
    
    if data.empty:
        return "No historical data available for analysis."
    
    # Get the prompt template for the selected style
    style_prompt = ANALYSIS_STYLES.get(style, ANALYSIS_STYLES["Technical Analysis"])
    
    # Format the data for the API
    indicators = format_indicator_data(data)
    hist_data = format_historical_data(data)
    
    # Create the prompt with real data
    timeframe = "daily"
    if data.index.freq is not None:
        freq_str = str(data.index.freq)
        if 'T' in freq_str or 'min' in freq_str:
            timeframe = "minute"
        elif 'H' in freq_str:
            timeframe = "hourly"
        elif 'D' in freq_str:
            timeframe = "daily"
        elif 'W' in freq_str:
            timeframe = "weekly"
        elif 'M' in freq_str:
            timeframe = "monthly"
    
    prompt = style_prompt.format(
        symbol=symbol,
        timeframe=timeframe,
        risk_reward=risk_reward,
        hist_data=hist_data,
        live_price=live_price,
        indicators=indicators
    )
    
    try:
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are an expert financial analyst providing detailed market analysis."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1000,
            temperature=0.7
        )
        
        return response.choices[0].message.content
    
    except Exception as e:
        return f"Error generating analysis: {str(e)}"
