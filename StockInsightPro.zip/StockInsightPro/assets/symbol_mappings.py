# Symbol mapping for yfinance compatibility
SYMBOL_MAPPING = {
    "XAUUSD": "GC=F", "XAGUSD": "SI=F", "HG1!": "HG=F", "AL1!": "ALI=F",
    "NI1!": "NICKEL", "ZN1!": "ZINC", "XPTUSD": "PL=F", "XPDUSD": "PA=F",
    "CL1!": "CL=F", "BZ1!": "BZ=F", "NG1!": "NG=F", "RB1!": "RB=F",
    "HO1!": "HO=F", "QL1!": "ICI=F", "EURUSD": "EURUSD=X", "USDJPY": "USDJPY=X",
    "GBPUSD": "GBPUSD=X", "USDCHF": "USDCHF=X", "AUDUSD": "AUDUSD=X",
    "USDCAD": "USDCAD=X", "NZDUSD": "NZDUSD=X"
}

# Timeframe limits for yfinance
TIMEFRAME_LIMITS = {
    "1m": 7, "5m": 60, "15m": 60, "1h": 730, "4h": 730,
    "1d": None, "1w": None, "1mo": None
}

# Pre-defined market searches (20 popular symbols)
PREDEFINED_MARKETS = [
    "^NSEI: NIFTY 50 (India)", "^GSPC: S&P 500 (USA)", "^DJI: Dow Jones (USA)",
    "^IXIC: NASDAQ (USA)", "^FTSE: FTSE 100 (UK)", "^N225: Nikkei 225 (Japan)",
    "EURUSD=X: EUR/USD", "USDJPY=X: USD/JPY", "GBPUSD=X: GBP/USD", "AUDUSD=X: AUD/USD",
    "XAUUSD: Gold (GC=F)", "XAGUSD: Silver (SI=F)", "CL1!: Crude Oil (CL=F)",
    "BTC-USD: Bitcoin", "ETH-USD: Ethereum", "AAPL: Apple Inc.", "MSFT: Microsoft Corp.",
    "GOOGL: Alphabet Inc.", "AMZN: Amazon.com Inc.", "TSLA: Tesla Inc."
]

# Analysis style options
ANALYSIS_STYLES = {
    "Technical Analysis": "Comprehensive technical analysis with entry/exit levels",
    "Trend Following": "Momentum-based trend analysis with strong emphasis on trend direction",
    "Risk-Averse": "Conservative approach prioritizing capital preservation",
    "SMC (Smart Money Concepts)": "Institutional behavior and order block analysis",
    "Price Action": "Pure price movement analysis with candlestick patterns",
    "ICT (Inner Circle Trader)": "Market structure and liquidity-based analysis"
}

# Risk-reward ratios
RISK_REWARD_RATIOS = ["1:1", "1:2", "1:3", "1:5", "2:1"]
