# Init file to make assets a package
